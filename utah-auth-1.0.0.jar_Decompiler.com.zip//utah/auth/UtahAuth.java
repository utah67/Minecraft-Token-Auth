package utah.auth;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UtahAuth implements ModInitializer {
   public static final String MOD_ID = "utah-auth";
   public static final Logger LOGGER = LoggerFactory.getLogger("utah-auth");

   public void onInitialize() {
      LOGGER.info("Hello Fabric world!");
   }
}
