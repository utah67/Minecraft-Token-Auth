package utah.auth.mixin.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import utah.auth.screen.TokenLoginScreen;

@Environment(EnvType.CLIENT)
@Mixin({class_442.class})
public class TitleScreenMixin {
   @Inject(
      at = {@At("TAIL")},
      method = {"method_25426"}
   )
   private void addAuthLoginButton(CallbackInfo ci) {
      class_442 screen = (class_442)this;
      class_310 mc = class_310.method_1551();
      ScreenAccessor accessor = (ScreenAccessor)screen;
      accessor.invokeAddRenderableWidget(class_4185.method_46430(class_2561.method_43470("AuthLogin"), (button) -> {
         mc.method_1507(new TokenLoginScreen(screen));
      }).method_46434(10, 10, 100, 20).method_46431());
   }
}
