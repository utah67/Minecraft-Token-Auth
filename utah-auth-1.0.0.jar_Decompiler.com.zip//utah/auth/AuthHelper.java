package utah.auth;

import java.lang.reflect.Field;
import java.util.Optional;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_320;
import net.minecraft.class_320.class_321;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public class AuthHelper {
   private static final Logger LOGGER = LoggerFactory.getLogger("utah-auth");

   public static boolean loginWithToken(String accessToken) {
      try {
         class_310 mc = class_310.method_1551();
         if (tryDirectSessionToken(mc, accessToken)) {
            return true;
         } else {
            LOGGER.warn("Direct token authentication failed. Token may need to be exchanged through Microsoft OAuth flow.");
            return false;
         }
      } catch (Exception var2) {
         LOGGER.error("Unexpected error during authentication", var2);
         return false;
      }
   }

   private static boolean tryDirectSessionToken(class_310 mc, String accessToken) {
      try {
         class_320 currentUser = mc.method_1548();
         if (currentUser != null) {
            UUID profileId = currentUser.method_44717();
            class_321 userType = currentUser.method_35718();
            class_320 newUser = new class_320(currentUser.method_1676(), profileId, accessToken, Optional.empty(), Optional.empty(), userType);
            if (setUserField(mc, newUser)) {
               LOGGER.info("Set session token directly for user: {}", currentUser.method_1676());
               return true;
            }
         } else {
            LOGGER.warn("No current user found. Cannot set session token without profile information.");
         }
      } catch (Exception var6) {
         LOGGER.debug("Direct session token failed: {}", var6.getMessage());
      }

      return false;
   }

   private static boolean setUserField(class_310 mc, class_320 user) {
      try {
         Field userField = null;
         Field[] var3 = class_310.class.getDeclaredFields();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            Field field = var3[var5];
            if (field.getType() == class_320.class) {
               userField = field;
               break;
            }
         }

         if (userField != null) {
            userField.setAccessible(true);
            userField.set(mc, user);
            return true;
         }

         LOGGER.error("Could not find user field in Minecraft class");
      } catch (Exception var7) {
         LOGGER.error("Failed to set user field", var7);
      }

      return false;
   }
}
