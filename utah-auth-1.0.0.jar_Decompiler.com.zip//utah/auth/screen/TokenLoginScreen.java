package utah.auth.screen;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import utah.auth.AuthHelper;

@Environment(EnvType.CLIENT)
public class TokenLoginScreen extends class_437 {
   private class_342 tokenField;
   private class_4185 loginButton;
   private String statusMessage = "";
   private final class_437 parent;

   public TokenLoginScreen(class_437 parent) {
      super(class_2561.method_43470("AuthLogin"));
      this.parent = parent;
   }

   protected void method_25426() {
      super.method_25426();
      int centerX = this.field_22789 / 2;
      int centerY = this.field_22790 / 2;
      this.tokenField = new class_342(this.field_22793, centerX - 150, centerY - 20, 300, 20, class_2561.method_43470("Access Token"));
      this.tokenField.method_1880(2000);
      this.tokenField.method_47404(class_2561.method_43470("Paste your access token here..."));
      this.method_37063(this.tokenField);
      this.loginButton = class_4185.method_46430(class_2561.method_43470("Login"), (button) -> {
         this.handleLogin();
      }).method_46434(centerX - 75, centerY + 20, 150, 20).method_46431();
      this.method_37063(this.loginButton);
      class_4185 cancelButton = class_4185.method_46430(class_2561.method_43470("Cancel"), (button) -> {
         this.field_22787.method_1507(this.parent);
      }).method_46434(centerX - 75, centerY + 50, 150, 20).method_46431();
      this.method_37063(cancelButton);
      this.method_48265(this.tokenField);
   }

   public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float delta) {
      this.method_25420(guiGraphics, mouseX, mouseY, delta);
      guiGraphics.method_51433(this.field_22793, "AuthLogin", 10, 10, 16777215, true);
      guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 50, 16777215);
      guiGraphics.method_51433(this.field_22793, "Access Token:", this.field_22789 / 2 - 150, this.field_22790 / 2 - 50, 16777215, false);
      if (!this.statusMessage.isEmpty()) {
         int color = this.statusMessage.startsWith("Error") ? 16733525 : 5635925;
         guiGraphics.method_25300(this.field_22793, this.statusMessage, this.field_22789 / 2, this.field_22790 / 2 + 100, color);
      }

      super.method_25394(guiGraphics, mouseX, mouseY, delta);
   }

   public void method_25393() {
      super.method_25393();
   }

   private void handleLogin() {
      String token = this.tokenField.method_1882().trim();
      if (token.isEmpty()) {
         this.statusMessage = "Error: Please enter an access token";
      } else {
         this.statusMessage = "Logging in...";
         this.loginButton.field_22763 = false;
         (new Thread(() -> {
            try {
               boolean success = AuthHelper.loginWithToken(token);
               this.field_22787.execute(() -> {
                  if (success) {
                     this.statusMessage = "Successfully logged in!";
                     (new Thread(() -> {
                        try {
                           Thread.sleep(1000L);
                           this.field_22787.execute(() -> {
                              this.field_22787.method_1507(this.parent);
                           });
                        } catch (InterruptedException var2) {
                           Thread.currentThread().interrupt();
                        }

                     })).start();
                  } else {
                     this.statusMessage = "Error: Failed to authenticate. Check your token.";
                     this.loginButton.field_22763 = true;
                  }

               });
            } catch (Exception var3) {
               this.field_22787.execute(() -> {
                  this.statusMessage = "Error: " + var3.getMessage();
                  this.loginButton.field_22763 = true;
               });
            }

         })).start();
      }
   }

   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
      if (keyCode == 256) {
         this.field_22787.method_1507(this.parent);
         return true;
      } else {
         return super.method_25404(keyCode, scanCode, modifiers);
      }
   }
}
